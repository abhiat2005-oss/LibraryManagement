# Library Management System

A beginner-friendly website made with HTML, CSS and JavaScript.

## Features
- Add books with unique Book IDs
- Search by ID, title or author
- Issue and return books
- Delete books
- Dashboard counts
- Save records in the current browser using localStorage

## Run locally
Open `index.html` in a browser, or use the Live Server extension in VS Code.

## Publish with GitHub Pages
1. Create a new public repository on GitHub.
2. Upload `index.html` (and this README if desired) to the repository root.
3. Open repository Settings -> Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Choose `main` and `/(root)`, then Save.
6. Wait a few minutes. Your site URL will be shown in the Pages section.

Note: localStorage is per browser/device. This demo has no shared database or user login.
